// auto_correlation.cpp : Defines the entry point for the console application.
//
//**************************************Header file***************************************//
#include "stdafx.h"
#include <iostream>									// for input and output from consol
#include <fstream>									// for input and output from file
#include<string>									// for read and write string from file 
#include<vector>									// for store data from file
#include <cmath>
#include <sstream>
using namespace std;
 
void dc_to_ci(int file, char vowel);
void vowel_recognition();
char vowel[5]={'a','e','i','o','u'};
vector <long double> ceps_coeff_rsw ,refrence_vowel,test_vowel;

int _tmain(int argc, _TCHAR* argv[])
{
	/*int flag;
	cout<< "Do you want to test data online or offline " << endl<<" press 0 (zero) for offilne and press 1 for online data test = ";
	cin>>flag; 
	if (flag==1){
	system("Recording_Module.exe 3 yes_no.wav yes_no.txt");	// to get rhe real time recoding and there txt file 
	}else if(flag==0){
	
	}else{
	cout<<"wrong input ! default run offline";
	}
	*/
	cout<<"\n ...Yes / NO Jarvis...\n\n";				//print on the consol
 
	for(int v=0;v<=4;v++){
	/******************************for set refrence data one by one wovel***************************************************/
		for(int i =1;i<=10;i++){
			//dc_to_ci(i,vowel[v]);
		}
/*****************************************to test vowel file  ************************************************/
		for(int i =11;i<=20;i++){
			dc_to_ci(i,vowel[v]);
			vowel_recognition();
		}
		//dc_to_ci(12,vowel[v]);
			//vowel_recognition();
	}
	return 0;
}
/*******************end of main ***********************/

void vowel_recognition(){
	/**************start*****************/
ofstream refrence_file_out;
ofstream test_file_out;
//refrence_file_out.open("refrence/refrence_file_u.txt");				// open file to write

//if(check refrence_file size is zero ){
	/*
		long double sum_ceps_rsw=0.0,avg_ceps_rsw;
	for(long int j=0; j<5;j++){
		for(long long int i =0;i<12;i++){
			sum_ceps_rsw=0;
			for(int k=i;k<ceps_coeff_rsw.size();k++){
				sum_ceps_rsw += ceps_coeff_rsw[k+12*j] ;				
				k=k+59;
			}
			avg_ceps_rsw=sum_ceps_rsw/10;
			//cout<<"avg_ceps_rsw("<<j<<") = "<<avg_ceps_rsw<<endl;
			refrence_vowel.push_back(avg_ceps_rsw);
			refrence_file_out<<avg_ceps_rsw<<endl;	// write into file  refrence data of ci
		}
	}		
	/***/
/*
for(long long int i =0;i<=ceps_coeff_rsw.size()-1;i++){
cout<<"ceps_coeff_rsw("<<i<<") = "<<ceps_coeff_rsw[i]<<endl;
}*/ 

test_file_out.open("test_file.txt");
	long double sum_ceps_rsw=0.0,avg_ceps_rsw;
	for(long int j=0; j<5;j++){
		for(long long int i =0;i<12;i++){
			sum_ceps_rsw=0;
			for(int k=i;k<ceps_coeff_rsw.size();k++){
				sum_ceps_rsw += ceps_coeff_rsw[k+12*j] ;				
				k=k+59;
			}
			avg_ceps_rsw=sum_ceps_rsw/10;
			//cout<<"avg_ceps_rsw("<<i<<") = "<<avg_ceps_rsw<<endl;
			test_vowel.push_back(avg_ceps_rsw);
			test_file_out<<avg_ceps_rsw<<endl;	// write into file  refrence data of ci
		}
	}
	/***/
/*******************tokhura distance  ***********************/ // run this tokhura for each refrence a,e,i,o,u	
ifstream refrence_file_in;
ifstream test_file_in;
test_file_in.open("test_file.txt");
vector <long double> tokhura_distance;
double Wi[12]={1.0, 3.0, 7.0, 13.0, 19.0, 22.0, 25.0, 33.0, 42.0, 50.0, 56.0, 61.0};
long double Dtcep[12];
int ref[60];
long double Cir ,Cit;
string strngfromfiledata = "";
while(getline(test_file_in,strngfromfiledata)){
	  Cit = stod(strngfromfiledata);
	test_vowel.push_back(Cit);	
	//cout<<"Cit="<<Cit<<endl;
}
for(int i=0;i<=4;i++){
	ifstream refrence_file_in;
	string strngfromfiledata = "";
std::ostringstream s; 
s << "refrence/refrence_file_"<<vowel[i]<<".txt";
 //cout<<"vowel["<<i<<"]="<<vowel[i]<<endl<<s.str();
std::string query(s.str());								 
refrence_file_in.open(s.str());
while(getline(refrence_file_in,strngfromfiledata)){
	  Cir = stod(strngfromfiledata);
	  //cout<<"Cir="<<Cir<<endl;
	  refrence_vowel.push_back(Cir);		
}
//cout<<"test_vowel.size()="<<test_vowel.size()<<endl;
double sum;  
float temp_wi;
for(int j=0;j<=4;j++){
	sum=0;
	for(int i=j*12; i<(j+1)*12;i++){
		sum+= Wi[i%12]*((test_vowel[i]-refrence_vowel[i])*(test_vowel[i]-refrence_vowel[i])); 
}
tokhura_distance.push_back(sum);
//cout<<"sum="<<sum<<endl;
}
refrence_vowel.clear();
}
for( int i=0; i<tokhura_distance.size();i++)
{
	//cout<<"tokhura_distance("<<i<<") = "<<tokhura_distance.at(i)<<endl;
}
									 //find min in 5*5 =25 value 
//char vowel[5]={'a','e','i','o','u'};
	int index;
	   double min=tokhura_distance.at(0);
		for(int i=1;i<tokhura_distance.size();i++){
			if(min>tokhura_distance[i]){
				min=tokhura_distance[i];
				index=i;
			}		
		}
			cout<< " min= " << min<< endl;
			//cout<< index%5<<" index= " << index<< endl;
			cout<< "the vowel is " <<vowel[index%5]<< endl;
	tokhura_distance.clear();
	ceps_coeff_rsw.clear();
	refrence_vowel.clear();
	test_vowel.clear();
	/******************end*********************/
}


void dc_to_ci(int file, char vowel){

		//***************************************variable ********************************//
ifstream   yes_no_file;								 
ofstream   yes_no_ste_file;							 

	//yes_no_file.open("test.txt");						 
//yes_no_file.open("yes_no.txt");		
yes_no_ste_file.open("yes_no_ste.txt");				 
std::ostringstream s;
//s << "recordings/recordings/a_" << file<<".txt";
s << "recording/204101031_"<<vowel<<"_" << file<<".txt";
std::string query(s.str());
	yes_no_file.open(s.str());
 cout<<s.str()<<endl;
string strngfromfile = "";
int chunk = 1, totalCount = 1, srn = 1 ,zcr=0, zcr_count=0,raw_count=0;
long long int total = 0 ,no_of_element=0;
long double sum =0, avg=0;
vector <long double> raw_data, raw_ste;			 

//*****************************************start while loop***********************************************//
while (getline (yes_no_file, strngfromfile)) {		 
	 
  if(chunk <= 320) {								 
	  raw_data.push_back(stod(strngfromfile));		   
	 long double numfromfile = stod(strngfromfile);	 
	 sum += numfromfile;
  
	 total =total+ numfromfile*numfromfile;	 		 
	  chunk++;										 
  }
  if(chunk == 320) {								 
	  raw_ste.push_back(total/320);					 
		yes_no_ste_file<<total/320<<endl;			 
	 	  srn++; chunk = 1;  total = 0;				 
  }
  no_of_element++;
}		
 avg = sum /no_of_element ;
 //*****************************************end of while loop ************************************************//
 //cout<<endl<<"avg for silence = "<<avg<<endl;
 /**********************dc shift **************/
 total=0;
 for (long long int i= 0; i<raw_data.size()-2;i++){	// for loop for all data to check yes or no  
	  raw_data.at(i)=raw_data.at(i)-avg;
	 total++;
	 }
 //cout<<endl<<"total elecment = "<<total<< "total chunk= "<<srn<<endl;
 total=0;
 /**********************dc shift  end**************/
 /****************find maximum from data to make normalized **************************/
 long long int max_element=0, min_element=0;
 for(long long int i= 0; i<raw_data.size()-1;i++){	 
		if(raw_data.at(i)< raw_data.at(i+1)){		 
		
			if(max_element<raw_data.at(i+1))
			max_element= raw_data.at(i+1);				 
		}else if(raw_data.at(i)> raw_data.at(i+1)){		 
		
			if(min_element>raw_data.at(i+1))
			min_element= raw_data.at(i+1);				 
		}
 }
// cout<<endl<<"max_element = "<<max_element<<endl;
//cout<<endl<<"min_element = "<<min_element<<endl;
long  double normalized_val1=0, normalized_val=0;
int check=0;
if(max_element>abs(min_element)){
	normalized_val=10000.00/max_element;
	check=1;
}else{
	normalized_val=10000.00/abs(min_element);
	check=1;
}
  
// cout<<endl<<"normalized_val = "<<normalized_val<<endl;
/*********************************find 5  stable frame  *****************************************/
long double temp_max;
total=0;
if(max_element>abs(min_element)){
	temp_max= max_element;
}else{
	 temp_max=abs(min_element);
}

vector <long double> raw_data_5_frame;

long double sample_5_frame_index=0,sample_5_frame_chunk=0,sample_5_frame_chunk_total=0;
chunk=1;
int t=0;
for(long long int i= 0; i<raw_data.size()-1;i++){	   	 
  if(chunk <= 319){									 
	  if((long int)max_element==(long int)(raw_data[i]))
	  {
		  sample_5_frame_index=i;
		  sample_5_frame_chunk=chunk;
		  sample_5_frame_chunk_total=total;
		  t=1;
	 // break;
	  }
	 chunk++;
	 if(t){
	 if(i<=(sample_5_frame_index+1601))
	 raw_data_5_frame.push_back(raw_data[i]);
	 }
  }
  if(chunk == 319) {								 
	 total++;
	    chunk = 1;   				 
	  }
 }
 
/*********************************end find 5  stable frame  *****************************************/
/****************************normalization start*************************************/
if(check){
	for(long long int i= 0; i<raw_data.size()-1;i++){	// for loop to calculate   
		raw_data.at(i)=raw_data.at(i)*normalized_val;
 }
}
/*************************normalization end *******************************/
/*********************************hamming window function*****************************************/

chunk=1;
long double hamming_window=0;
total=0;
for(long long int i= 0; i<raw_data_5_frame.size()-1;i++){	 
		 	
  if(chunk <= 319){									 
	  double x= (2*chunk*22/7)/319;
	 hamming_window= 0.54-0.46* cos (x);
	  raw_data_5_frame.at(i)=raw_data_5_frame.at(i)*hamming_window;
	 chunk++;										 
  }
  if(chunk == 319) {								 
	 total++;
	    chunk = 1;   				 
	//	cout<<"after hamming window data.at("<<i<<") = "<<raw_data_5_frame.at(i)<<endl;
  }
 }

//cout<<"total = "<<total<<endl;

/************************************loop for 5 frames  Ri , Ai , Ci ***************************************************/
 
/*******************find Ri's ******************/
vector <long double> Ri_data;
chunk = 1;
long double summ;
 int frame_count=1;
for (long long int frame=0 ; frame <raw_data_5_frame.size()-1;frame++){
	if(frame_count<=5)
	{
			for (long long int k= 0; k<=12;k++){	 
   
			 summ=0;
					 for(int i= 0; i<=319-k;i++){
						 if((frame+i+k)<=(raw_data_5_frame.size()-1)){
							summ = summ +(raw_data_5_frame.at(frame+i)*raw_data_5_frame.at(frame+i+k));
							}
						}
			 Ri_data.push_back(summ);
			//cout<<"Ri data["<<k<<"] = "<< summ<< endl;
			}

			frame_count++;
			frame=frame+318;
	}
}
/**********************************find Ai's********durbins algo**********usig 1D array*************************/
//cout<<"Ri_data = "<< Ri_data.size()<< endl;
long long int p=12;
vector <long double> alpha_new,alpha_old ,k, E, temp_Ri_data;
 long long int m,j;
vector <long double> ceps_coeff ;
chunk=1;
long double raised_sine_window=0;
total=0;
int Q=12; 
for (int f=0;f<=12;f++){
	temp_Ri_data.push_back(0);
		}
 frame_count=1;
for (long int frame=0 ; frame <=Ri_data.size()-1;frame++){
	if(frame_count<=5)
	{
		int g=frame;
		for (int f=0;f<=12;f++){
			temp_Ri_data.at(f)=Ri_data.at(g);
			g=g+1;
				//cout<<"temp_Ri_data " <<f<<" ="<< temp_Ri_data.at(f)<< endl;
		}
		//cout<<"temp_Ri_data = "<< temp_Ri_data.size()<< endl;
for (long long int i =0; i<=p;i++)
{
alpha_new.push_back(0);
alpha_old.push_back(0);
E.push_back(0);
k.push_back(0);
}

E.at(0)=temp_Ri_data.at(0);

for (int i=1; i<=p;i++ )
{
if(i==1){
	k.at(1)=temp_Ri_data.at(1)/temp_Ri_data.at(0);
}
else{
long double sum=0;
for (long long int j=1;j<=i-1;j++)
{
	alpha_old.at(j)=alpha_new.at(j);
	sum+=alpha_old.at(j)*temp_Ri_data.at(i-j); 
}
k.at(i)=(temp_Ri_data.at(i)-sum)/E.at(i-1);
}
alpha_new.at(i)=k.at(i);

for(long long int j=1;j<=i-1;j++ )
{
	alpha_new.at(j)=alpha_old.at(j)-k.at(i)*alpha_old.at(i-j);
}
	E.at(i)=((1-k.at(i)*k.at(i))*E.at(i-1));
}
for(long long int i=1; i<=p;i++)
{
	//cout<<"a("<<i<<") = "<<alpha_new.at(i)<<endl;
}
/********************* sign inverse of Ai's********************************/
for(long long int i=1; i<=p;i++)
{
	alpha_new.at(i) = -1 * alpha_new.at(i);	  
}
/********************* calculate Ci's********************************/
for ( int i =0; i<=p;i++)
{
ceps_coeff.push_back(0);
}
ceps_coeff.at(0)=log(temp_Ri_data.at(0));
for(m=1;m<=p;m++){
long double summa=0;
for(j=1;j<=m-1;j++){
	summa+=j*(ceps_coeff.at(j)*alpha_new.at(m-j))/m; 
	}
ceps_coeff.at(m)=alpha_new.at(m)+summa; 

}
for(int i=0; i<=p;i++){
	//cout<<"ceps_coeff("<<i<<") ="<<ceps_coeff.at(i)<<endl;
}
/*********************Apply Raised sine window on Ci's********************************/
chunk = 1; 
 
for(  int i= 1; i<=p;i++){	  	 
  if(chunk <= 12){	
	  double x= (chunk*22/7)/Q;
	 raised_sine_window=  1+ (Q/2)* sin (x);
	  ceps_coeff.at(i)=ceps_coeff.at(i)*raised_sine_window;
	 chunk++;										 
	 ceps_coeff_rsw.push_back(ceps_coeff[i]);
		//cout<<"ceps_coeff_rsw ("<<i<<") ="<<ceps_coeff_rsw.at(i)<<endl;
  }
  if(chunk == 12) {								 
	 total++;
	    chunk = 1;   				 
  }
 }
			frame_count++;
			frame=frame+12;
	}
}	 
}

